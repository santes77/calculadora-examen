package com.adso.calculadora

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var num1: Double = 0.0
    private var num2: Double = 0.0
    private var operator: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonAdd = findViewById<Button>(R.id.buttonAdd)
        val buttonSubtract = findViewById<Button>(R.id.buttonSubtract)
        val buttonMultiply = findViewById<Button>(R.id.buttonMultiply)
        val buttonDivide = findViewById<Button>(R.id.buttonDivide)
        val buttonCalculate = findViewById<Button>(R.id.buttonCalculate)
        val editTextNumber1 = findViewById<EditText>(R.id.editTextNumber1)
        val editTextNumber2 = findViewById<EditText>(R.id.editTextNumber2)
        val textViewResult = findViewById<TextView>(R.id.textViewResult)

        buttonAdd.setOnClickListener {
            operator = "+"
        }

        buttonSubtract.setOnClickListener {
            operator = "-"
        }

        buttonMultiply.setOnClickListener {
            operator = "*"
        }

        buttonDivide.setOnClickListener {
            operator = "/"
        }

        buttonCalculate.setOnClickListener {
            num1 = editTextNumber1.text.toString().toDouble()
            num2 = editTextNumber2.text.toString().toDouble()

            val result = when (operator) {
                "+" -> num1 + num2
                "-" -> num1 - num2
                "*" -> num1 * num2
                "/" -> num1 / num2
                else -> 0
            }

            textViewResult.text = result.toString()
        }
    }



    }
